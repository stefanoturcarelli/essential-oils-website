Icons are generated and provided by the http://icomoon.io service.
